﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace Practico2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Familiar fam1 = new Familiar(01, "JEB2134", "Chevrolet", "Rojo", 44, 5000, 50, 303);
            Familiar fam2 = new Familiar(02, "FRA5298", "Fiat", "Azul", 48, 6500, 65, 300);
            Utilitario utl1 = new Utilitario(03, "LIO4906", "JAC", "Blanco", 60, 8000, 100, 1910);
            Utilitario utl2 = new Utilitario(04, "BEC0483", "Hyundai", "Blanco", 54, 9000, 85, 4500);
            Deportivo dep1 = new Deportivo(05, "MAL7249", "Ferrari", "Amarillo", 50, 15000, 70, 230);
            Deportivo dep2 = new Deportivo(06, "DOS0359", "Lamborghini", "Negro", 60, 30000, 75, 350);
            Alquiler alq1 = new Alquiler(1, "54336150", "099374051", "MELINA", "CAMUS", new List<Vehiculo> { fam1 }, 6);
            Alquiler alq2 = new Alquiler(2, "87654321", "098888888", "ARMANDO", "PAREDES", new List<Vehiculo> { utl1, utl2 }, 20);
            Alquiler alq3 = new Alquiler(3, "27452845", "097777777", "BENITO", "CAMELO", new List<Vehiculo> { dep2 }, 3);
            alq1.setPrecioTotal();
            alq1.setVehAlquilados();
            alq2.setPrecioTotal();
            alq2.setVehAlquilados();
            alq3.setPrecioTotal();
            alq3.setVehAlquilados();
            List<Vehiculo> colVehiculos = new List<Vehiculo> { fam1, fam2, utl1, utl2, dep1, dep2 };
            List<Alquiler> colAlquileres = new List<Alquiler> { alq1, alq2, alq3 };
            Sucursal sucursal = new Sucursal(01, "18 de Julio", colAlquileres, colVehiculos);
            int opcion = 0;
            short numAlq = 04;
            short numVeh = 07;
            do
            {
                bool error;
                do
                {
                    Console.WriteLine("MENU:\n1. Alquilar vehiculo/os\n2. Agregar vehiculo\n3. Ver vehiculos de la sucursal\n4. Ver alquileres de la sucursal\n5. Ver clientes de la sucursal\n0. Salir");
                    try
                    {
                        error = false;
                        opcion = int.Parse(Console.ReadLine());
                    }
                    catch (FormatException)
                    {
                        Console.Clear();
                        Console.WriteLine("Error, opcion invalida\n");
                        error = true;
                    }
                    catch (OverflowException)
                    {
                        Console.Clear();
                        Console.WriteLine("Error, opcion invalida\n");
                        error = true;
                    }
                    catch (Exception)
                    {
                        Console.Clear();
                        Console.WriteLine("Error, opcion invalida\n");
                        error = true;
                    }
                } while (opcion < 0 || opcion > 5 || error);//MENU PRINCIPAL
                int opcion1 = 0;
                switch (opcion)
                {
                    case 1:
                        Console.Clear();
                        Alquiler alquiler = new Alquiler();
                        List<Vehiculo> colVehAlquilados = new List<Vehiculo>();
                        do
                        {
                            do
                            {
                                error = false;
                                try
                                {
                                    Console.WriteLine("1.Anadir vehiculo al alquiler\n0.Continuar");
                                    opcion1 = int.Parse(Console.ReadLine());
                                }
                                catch (FormatException)
                                {
                                    Console.Clear();
                                    Console.WriteLine("Error, opcion invalida\n");
                                    error = true;
                                }
                                catch (OverflowException)
                                {
                                    Console.Clear();
                                    Console.WriteLine("Error, opcion invalida\n");
                                    error = true;
                                }
                                catch (Exception)
                                {
                                    Console.Clear();
                                    Console.WriteLine("Error, opcion invalida\n");
                                    error = true;
                                }
                            } while (opcion1 < 0 || opcion1 > 1 || error);
                            if (opcion1 == 1)
                            {
                                short num = 0;
                                Console.Clear();
                                do
                                {
                                    error = false;
                                    try
                                    {
                                        Console.WriteLine("VEHICULOS");
                                        foreach (Vehiculo vehiculo in sucursal.getColVehiculos())
                                        {
                                            Console.WriteLine($"{vehiculo.getNumero()}. {vehiculo.getMarca()} / {vehiculo.getMatricula()}");
                                        }
                                        Console.WriteLine("Ingrese el numero del vehiculo:");
                                        num = short.Parse(Console.ReadLine());
                                    }
                                    catch (FormatException)
                                    {
                                        Console.Clear();
                                        Console.WriteLine("Error, opcion invalida\n");
                                        error = true;
                                    }
                                    catch (OverflowException)
                                    {
                                        Console.Clear();
                                        Console.WriteLine("Error, opcion invalida\n");
                                        error = true;
                                    }
                                    catch (Exception)
                                    {
                                        Console.Clear();
                                        Console.WriteLine("Error, opcion invalida\n");
                                        error = true;
                                    }
                                } while (num <= 0 || num > sucursal.getColVehiculos().Count || error);
                                Console.Clear();
                                foreach (Vehiculo vehiculo in sucursal.getColVehiculos())
                                {
                                    if (num == vehiculo.getNumero() && vehiculo.getEstado() == false)
                                    {
                                        vehiculo.setEstado(true);
                                        colVehAlquilados.Add(vehiculo);
                                        Console.WriteLine("Vehiculo agregado correctamente");
                                    }
                                    else if (num == vehiculo.getNumero() && vehiculo.getEstado())
                                    {
                                        Console.WriteLine($"El vehiculo {vehiculo.getNumero()} ya esta alquilado");
                                    }
                                }
                            }
                        } while (opcion1 != 0);
                        Console.Clear();
                        alquiler.setNumero(numAlq);
                        alquiler.setColVehiculos(colVehAlquilados);
                        Console.WriteLine("Ingrese el documento del cliente:");
                        alquiler.setDocumento(Console.ReadLine());
                        Console.WriteLine("Ingrese el telefono del cliente:");
                        alquiler.setTelefono(Console.ReadLine());
                        Console.WriteLine("Ingrese el nombre del cliente:");
                        alquiler.setNombre(Console.ReadLine().ToUpper());
                        Console.WriteLine("Ingrese el apellido del cliente:");
                        alquiler.setApellido(Console.ReadLine().ToUpper());
                        short cantDias = 0;
                        do
                        {
                            error = false;
                            try
                            {
                                Console.WriteLine("Ingrese la cantidad de dias del alquiler:");
                                cantDias = short.Parse(Console.ReadLine());
                            }
                            catch (FormatException)
                            {
                                Console.WriteLine("Error, valor invalido\n");
                                error = true;
                            }
                            catch (OverflowException)
                            {
                                Console.WriteLine("Error, valor invalido\n");
                                error = true;
                            }
                            catch (Exception)
                            {
                                Console.WriteLine("Error, valor invalido\n");
                                error = true;
                            }
                        } while (cantDias <= 0 || error);
                        alquiler.setDetalle(alquiler.getVehiculos().Count, cantDias);
                        alquiler.setPrecioTotal();
                        if (alquiler.getDocCliente() != string.Empty || alquiler.getTelCliente() != string.Empty || alquiler.getNombreCliente() != string.Empty || alquiler.getApellidoCliente() != string.Empty)
                        {
                            sucursal.addAlquiler(alquiler);
                            numAlq++;
                        }
                        else
                        {
                            Console.WriteLine("Uno de los valores ingresados es invalido, intentelo nuevamente\n");
                            Console.WriteLine("ENTER para continuar");
                            Console.ReadLine();
                        }
                        break;//AÑADIR ALQUILER
                    case 2:
                        Console.Clear();
                        Vehiculo veh = new Vehiculo();
                        veh.setNumero(numVeh);
                        Console.WriteLine("Ingrese la matricula del vehiculo:");
                        veh.setMatricula(Console.ReadLine());
                        Console.WriteLine("Ingrese la marca del vehiculo:");
                        veh.setMarca(Console.ReadLine());
                        Console.WriteLine("Ingrese el color del vehiculo:");
                        veh.setColor(Console.ReadLine());
                        veh.setEstado(false);
                        do
                        {
                            error = false;
                            try
                            {
                                Console.WriteLine("Ingrese la capacidad del tanque del vehiculo:");
                                veh.setCapTanque(short.Parse(Console.ReadLine()));
                            }
                            catch (FormatException)
                            {
                                Console.WriteLine("Error, valor invalido\n");
                                error = true;
                            }
                            catch (OverflowException)
                            {
                                Console.WriteLine("Error, valor invalido\n");
                                error = true;
                            }
                            catch (Exception)
                            {
                                Console.WriteLine("Error, valor invalido\n");
                                error = true;
                            }
                        } while (error || veh.getCapTanque() <= 0);
                        do
                        {
                            error = false;
                            try
                            {
                                Console.WriteLine("Ingrese el precio de alquiler diario del vehiculo:");
                                veh.setPrecioAlquilerDiario(int.Parse(Console.ReadLine()));
                            }
                            catch (FormatException)
                            {
                                Console.WriteLine("Error, valor invalido\n");
                                error = true;
                            }
                            catch (OverflowException)
                            {
                                Console.WriteLine("Error, valor invalido\n");
                                error = true;
                            }
                            catch (Exception)
                            {
                                Console.WriteLine("Error, valor invalido\n");
                                error = true;
                            }
                        } while (error || veh.getPrecioAlquilerDiario() < 0);
                        do
                        {
                            error = false;
                            try
                            {
                                Console.WriteLine("Ingrese la distancia que el vehiculo recorre con un litro de gasolina:");
                                veh.setKmLitro(short.Parse(Console.ReadLine()));
                            }
                            catch (FormatException)
                            {
                                Console.WriteLine("Error, valor invalido\n");
                                error = true;
                            }
                            catch (OverflowException)
                            {
                                Console.WriteLine("Error, valor invalido\n");
                                error = true;
                            }
                            catch (Exception)
                            {
                                Console.WriteLine("Error, valor invalido\n");
                                error = true;
                            }
                        } while (error || veh.getKmLitro() <= 0);
                        Console.Clear();
                        if (veh.getMatricula() != string.Empty)
                        {
                            Console.WriteLine("TIPO DEL VEHICULO:\n1. Familiar\n2. Utilitario\n3. Deportivo\n");
                            short opcTipo;
                            do
                            {
                                opcTipo = 0;
                                try
                                {
                                    Console.WriteLine("Ingrese el tipo del vehiculo:");
                                    opcTipo = short.Parse(Console.ReadLine());
                                }
                                catch (FormatException)
                                {
                                    Console.WriteLine("Error, valor invalido\n");
                                }
                                catch (OverflowException)
                                {
                                    Console.WriteLine("Error, valor invalido\n");
                                }
                                catch (Exception)
                                {
                                    Console.WriteLine("Error, valor invalido\n");
                                }
                            } while (opcTipo < 1 || opcTipo > 3);
                            switch (opcTipo)
                            {
                                case 1:
                                    short capMaletero;
                                    do
                                    {
                                        capMaletero = 0;
                                        error = false;
                                        try
                                        {
                                            Console.WriteLine("Ingrese la capacidad del maletero del vehiculo:");
                                            capMaletero = short.Parse(Console.ReadLine());
                                        }
                                        catch (FormatException)
                                        {
                                            Console.WriteLine("Error, valor invalido\n");
                                            error = true;
                                        }
                                        catch (OverflowException)
                                        {
                                            Console.WriteLine("Error, valor invalido\n");
                                            error = true;
                                        }
                                        catch (Exception)
                                        {
                                            Console.WriteLine("Error, valor invalido\n");
                                            error = true;
                                        }
                                    } while (error || capMaletero <= 0);
                                    Familiar fam = new Familiar(veh.getNumero(), veh.getMatricula(), veh.getMarca(), veh.getColor(), veh.getCapTanque(), veh.getPrecioAlquilerDiario(), veh.getKmLitro(), capMaletero);
                                    sucursal.addVehiculo(fam);
                                    break;
                                case 2:
                                    short capCarga;
                                    do
                                    {
                                        capCarga = 0;
                                        error = false;
                                        try
                                        {
                                            Console.WriteLine("Ingrese la capacidad de carga del vehiculo:");
                                            capCarga = short.Parse(Console.ReadLine());
                                        }
                                        catch (FormatException)
                                        {
                                            Console.WriteLine("Error, valor invalido\n");
                                            error = true;
                                        }
                                        catch (OverflowException)
                                        {
                                            Console.WriteLine("Error, valor invalido\n");
                                            error = true;
                                        }
                                        catch (Exception)
                                        {
                                            Console.WriteLine("Error, valor invalido\n");
                                            error = true;
                                        }
                                    } while (error || capCarga <= 0);
                                    Utilitario utl = new Utilitario(veh.getNumero(), veh.getMatricula(), veh.getMarca(), veh.getColor(), veh.getCapTanque(), veh.getPrecioAlquilerDiario(), veh.getKmLitro(), capCarga);
                                    sucursal.addVehiculo(utl);
                                    break;
                                case 3:
                                    short velMaxima;
                                    do
                                    {
                                        velMaxima = 0;
                                        error = false;
                                        try
                                        {
                                            Console.WriteLine("Ingrese la velocidad maxima del vehiculo:");
                                            velMaxima = short.Parse(Console.ReadLine());
                                        }
                                        catch (FormatException)
                                        {
                                            Console.WriteLine("Error, valor invalido\n");
                                            error = true;
                                        }
                                        catch (OverflowException)
                                        {
                                            Console.WriteLine("Error, valor invalido\n");
                                            error = true;
                                        }
                                        catch (Exception)
                                        {
                                            Console.WriteLine("Error, valor invalido\n");
                                            error = true;
                                        }
                                    } while (error || velMaxima <= 0);
                                    Deportivo dep = new Deportivo(veh.getNumero(), veh.getMatricula(), veh.getMarca(), veh.getColor(), veh.getCapTanque(), veh.getPrecioAlquilerDiario(), veh.getKmLitro(), velMaxima);
                                    sucursal.addVehiculo(dep);
                                    break;
                            }
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("Uno de los valores ingresados es invalido, intentelo nuevamente\n");
                            Console.WriteLine("ENTER para continuar");
                            Console.ReadLine();
                        }
                        numVeh++;
                        break;//AÑADIR VEHICULOS
                    case 3:
                        int opcion2 = 0;
                        int opcion2_5;
                        Console.Clear();
                        Console.WriteLine("1. Ver todos los vehiculos (+ Info)\n2. Ver vehiculos alquilados\n3. Ver vehiculos sin alquilar");
                        do
                        {
                            error = false;
                            opcion2_5 = 0;
                            try
                            {
                                opcion2_5 = int.Parse(Console.ReadLine());
                            }
                            catch (FormatException)
                            {
                                Console.WriteLine("Error, opcion invalida\n");
                                error = true;
                            }
                            catch (OverflowException)
                            {
                                Console.WriteLine("Error, opcion invalida\n");
                                error = true;
                            }
                            catch (Exception)
                            {
                                Console.WriteLine("Error, opcion invalida\n");
                                error = true;
                            }
                        } while (opcion2_5 <= 0 || opcion2_5 > 3 || error);
                        do
                        {
                            switch (opcion2_5)
                            {
                                case 1:
                                    do
                                    {
                                        Console.Clear();
                                        Console.WriteLine("///////////LISTA DE VEHICULOS///////////\n");
                                        foreach (Vehiculo vehiculo in sucursal.getColVehiculos())
                                        {
                                            Console.WriteLine($"VEHICULO {vehiculo.getNumero()}: {vehiculo.getMarca()} / {vehiculo.getMatricula()}\n");
                                        }
                                        do
                                        {
                                            error = false;
                                            try
                                            {
                                                Console.WriteLine("Seleccione un vehiculo para ver los detalles (0 para volver):");
                                                opcion2 = int.Parse(Console.ReadLine());
                                            }
                                            catch (FormatException)
                                            {
                                                Console.WriteLine("Error, opcion invalida\n");
                                                error = true;
                                            }
                                            catch (OverflowException)
                                            {
                                                Console.WriteLine("Error, opcion invalida\n");
                                                error = true;
                                            }
                                            catch (Exception)
                                            {
                                                Console.WriteLine("Error, opcion invalida\n");
                                                error = true;
                                            }
                                        } while (opcion2 < 0 || opcion2 > sucursal.getColVehiculos().Count || error);
                                        if (opcion2 == 0)
                                        {
                                            break;
                                        }
                                        Console.Clear();
                                        foreach (Vehiculo vehiculo in sucursal.getColVehiculos())
                                        {
                                            if (opcion2 == vehiculo.getNumero())
                                            {
                                                Console.WriteLine($"VEHICULO {vehiculo.getNumero()}:\nTIPO: {vehiculo.GetType().Name}\nMARCA: {vehiculo.getMarca()}\nCOLOR: {vehiculo.getColor()}\nMATRICULA: {vehiculo.getMatricula()}\nPRECIO DE ALQUILER DIARIO: ${vehiculo.getPrecioAlquilerDiario()}");
                                                if (vehiculo is Familiar)
                                                {
                                                    Familiar familiar = vehiculo as Familiar;
                                                    Console.WriteLine($"CAPACIDAD DE MALETERO (lts): {familiar.getDatoAdicional()}");
                                                }
                                                else if (vehiculo is Utilitario)
                                                {
                                                    Utilitario utilitario = vehiculo as Utilitario;
                                                    Console.WriteLine($"CAPACIDAD DE CARGA (kg): {utilitario.getDatoAdicional()}");
                                                }
                                                else if (vehiculo is Deportivo)
                                                {
                                                    Deportivo deportivo = vehiculo as Deportivo;
                                                    Console.WriteLine($"VELOCIDAD MAXIMA (km/h): {deportivo.getDatoAdicional()}");
                                                }
                                            }
                                        }
                                        Console.WriteLine("ENTER para continuar");
                                        Console.ReadLine();
                                    } while (opcion2 != -1);
                                    break;//LISTA TODOS VEHICULOS
                                case 2:
                                    Console.Clear();
                                    Console.WriteLine("///////////LISTA DE VEHICULOS ALQUILADOS///////////\n");
                                    foreach (Vehiculo vehiculo in sucursal.getColVehiculos())
                                    {
                                        if (vehiculo.getEstado())
                                        {
                                            Console.WriteLine($"VEHICULO {vehiculo.getNumero()}: {vehiculo.getMarca()} / {vehiculo.getMatricula()}\n");
                                        }
                                    }
                                    Console.WriteLine("ENTER para continuar");
                                    Console.ReadLine();
                                    break;//LISTA VEHICULOS ALQUILADOS
                                case 3:
                                    Console.Clear();
                                    Console.WriteLine("///////////LISTA DE VEHICULOS SIN ALQUILAR///////////\n");
                                    foreach (Vehiculo vehiculo in sucursal.getColVehiculos())
                                    {
                                        if (vehiculo.getEstado() == false)
                                        {
                                            Console.WriteLine($"VEHICULO {vehiculo.getNumero()}: {vehiculo.getMarca()} / {vehiculo.getMatricula()}\n");
                                        }
                                    }
                                    Console.WriteLine("ENTER para continuar");
                                    Console.ReadLine();
                                    break;//LISTA VEHICULOS SIN ALQUILAR
                            }
                        } while (opcion2_5 < 1 || opcion2_5 > 3);
                        break;//LISTAR VEHICULOS
                    case 4:
                        int opcion3 = 0;
                        do
                        {
                            Console.Clear();
                            Console.WriteLine("///////////LISTA DE ALQUILERES///////////\n");
                            foreach (Alquiler alquler in sucursal.getColAlquileres())
                            {
                                Console.WriteLine($"ALQUILER {alquler.getNumero()}\n");
                            }
                            do
                            {
                                error = false;
                                try
                                {
                                    Console.WriteLine("Seleccione un alquiler para ver los detalles (0 para volver):");
                                    opcion3 = int.Parse(Console.ReadLine());
                                }
                                catch (FormatException)
                                {
                                    Console.WriteLine("Error, opcion invalida\n");
                                    error = true;
                                }
                                catch (OverflowException)
                                {
                                    Console.WriteLine("Error, opcion invalida\n");
                                    error = true;
                                }
                                catch (Exception)
                                {
                                    Console.WriteLine("Error, opcion invalida\n");
                                    error = true;
                                }
                            } while (opcion3 < 0 || opcion3 > sucursal.getColAlquileres().Count || error);
                            if (opcion3 == 0)
                            {
                                break;
                            }
                            Console.Clear();
                            foreach (Alquiler alquler in sucursal.getColAlquileres())
                            {
                                if (opcion3 == alquler.getNumero())
                                {
                                    Console.WriteLine($"ALQUILER {alquler.getNumero()}\nCLIENTE: {alquler.getNombreCliente()} {alquler.getApellidoCliente()}\nDOCUMENTO: {alquler.getDocCliente()}\nTELEFONO: {alquler.getTelCliente()}\nCANTIDAD DE VEHICULOS ALQUILADOS: {alquler.getDetalle().getCantVehiculos()}\nFECHA DE RETIRO DE LOS VEHICULOS: {alquler.getDetalle().getFechaRetiro().ToShortDateString()}\nCANTIDAD DE DIAS DE ALQUILER: {alquler.getDetalle().getCantDias()}\nPRECIO TOTAL: ${alquler.getPrecioTotal()}");
                                    if (alquler.getEstado() == false)
                                    {
                                        Console.WriteLine("ESTADO: El alquiler esta en progreso\n");
                                    }
                                    else
                                    {
                                        Console.WriteLine("ESTADO: El alquiler esta finalizado\n");
                                    }
                                    short finAlq = 0;
                                    while (((finAlq < 1 || finAlq > 2) && alquler.getEstado() == false) || error)
                                    {
                                        error = false;
                                        try
                                        {
                                            Console.WriteLine("El alquiler ya finalizo?\n1.Si\n2.No");
                                            finAlq = short.Parse(Console.ReadLine());
                                        }
                                        catch (FormatException)
                                        {
                                            Console.WriteLine("Error, opcion invalida\n");
                                            error = true;
                                        }
                                        catch (OverflowException)
                                        {
                                            Console.WriteLine("Error, opcion invalida\n");
                                            error = true;
                                        }
                                        catch (Exception)
                                        {
                                            Console.WriteLine("Error, opcion invalida\n");
                                            error = true;
                                        }
                                    }
                                    if (finAlq == 1 && alquler.getEstado() == false)
                                    {
                                        alquler.setEstado(true);
                                        alquler.unsetVehAlquilados();
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                            }
                            Console.WriteLine("ENTER para continuar");
                            Console.ReadLine();
                        } while (opcion3 != -1);
                        break;//LISTAR ALQUILERES
                    case 5:
                        string opcion4;
                        do
                        {
                            Console.Clear();
                            Console.WriteLine("///////////LISTA DE CLIENTES///////////\n");
                            List<string> clientes = new List<string>();
                            string cliente;
                            foreach (Alquiler alquler in sucursal.getColAlquileres())
                            {
                                cliente = alquler.getNombreCliente().ToUpper();
                                foreach (string client in clientes)
                                {
                                    if (cliente == client)
                                    {
                                        cliente = null;
                                        break;
                                    }
                                }
                                if (cliente != null) 
                                { 
                                    clientes.Add(cliente);
                                }
                                else
                                {
                                    
                                }
                            }
                            foreach (string client in clientes)
                            {
                                Console.WriteLine("- " + client + "\n");
                            }
                            Console.WriteLine("Ingrese el nombre de un cliente para ver sus alquileres (0 para volver):");
                            opcion4 = Console.ReadLine().ToUpper();
                            Console.Clear();
                            foreach (string client in clientes)
                            {
                                if (opcion4 == client)
                                {
                                    Console.WriteLine($"El cliente {client} hizo el/los alquiler/es:\n");
                                    foreach (Alquiler alquler in sucursal.getColAlquileres())
                                    {
                                        if (opcion4 == alquler.getNombreCliente())
                                        {
                                            Console.WriteLine($"- Alquiler {alquler.getNumero()}\n");
                                        }
                                    }
                                }
                            }
                            Console.WriteLine("ENTER para continuar");
                            Console.ReadLine();
                        } while (opcion4 != "0");
                        break;//LISTAR CLIENTES
                    case 0:
                        break;
                    default:
                        Console.WriteLine("Error, opcion invalida\n");
                        Console.WriteLine("ENTER para continuar");
                        Console.ReadLine();
                        break;
                }
                Console.Clear();
            } while (opcion != 0);
        }
    }
}