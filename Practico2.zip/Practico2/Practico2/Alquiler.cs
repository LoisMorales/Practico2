﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practico2
{
    internal class Alquiler
    {
        protected short numero;
        protected int precioTotal;
        protected string docCliente;
        protected string telCliente;
        protected string nombreCliente;
        protected string apellidoCliente;
        protected Detalle detalle;
        protected bool estado;
        protected List<Vehiculo> colVehiculos;
        public Alquiler() { }
        public Alquiler(short numero, string docCliente, string telCliente, string nombreCliente, string apellidoCliente, List<Vehiculo> colVehiculos, short cantDias)
        {
            this.numero = numero;
            this.docCliente = docCliente;
            this.telCliente = telCliente;
            this.nombreCliente = nombreCliente;
            this.apellidoCliente = apellidoCliente;
            detalle = new Detalle(colVehiculos.Count, cantDias);
            precioTotal = 0;
            this.colVehiculos = colVehiculos;
            estado = false;
        }
        public short getNumero() { return numero;}
        public int getPrecioTotal() {  return precioTotal;}
        public string getDocCliente() {  return docCliente;}
        public string getTelCliente() { return telCliente;}
        public string getNombreCliente() { return nombreCliente;}
        public string getApellidoCliente() { return apellidoCliente;}
        public Detalle getDetalle() {  return detalle;}
        public bool getEstado() => estado;
        public List<Vehiculo> getVehiculos() => this.colVehiculos;
        public void setNumero(short numero) => this.numero = numero;
        public void setDocumento(string documento) => this.docCliente = documento;
        public void setTelefono(string telefono) => this.telCliente = telefono;
        public void setNombre(string nombre) => this.nombreCliente = nombre;
        public void setApellido(string apellido) => this.apellidoCliente = apellido;
        public void setEstado(bool estado) {  this.estado = estado; }
        public void setColVehiculos(List<Vehiculo> colVehiculos) => this.colVehiculos = colVehiculos;
        public void setDetalle(int cantVehiculos, short cantDias) => this.detalle = new Detalle(cantVehiculos, cantDias);
        public void setPrecioTotal()
        {
            foreach(Vehiculo vehiculo in this.colVehiculos)
            {
                this.precioTotal += vehiculo.getPrecioAlquilerDiario() * this.detalle.getCantDias();
            }
        }
        public void setVehAlquilados()
        {
            foreach (Vehiculo vehiculo in this.colVehiculos)
            {
                vehiculo.setEstado(true);
            }
        }
        public void unsetVehAlquilados()
        {
            foreach(Vehiculo vehiculo in this.colVehiculos)
            {
                vehiculo.setEstado(false);
            }
        }
    }
}
