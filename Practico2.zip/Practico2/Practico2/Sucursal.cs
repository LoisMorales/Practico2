﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practico2
{
    internal class Sucursal
    {
        protected short numero;
        protected string direccion;
        protected List<Alquiler> colAlquileres;
        protected List<Vehiculo> colVehiculos;
        public Sucursal(short numero, string direccion, List<Alquiler> colAlquileres, List<Vehiculo> colVehiculos)
        {
            this.numero = numero;
            this.direccion = direccion;
            this.colAlquileres = colAlquileres;
            this.colVehiculos = colVehiculos;
        }
        public List<Alquiler> getColAlquileres() => colAlquileres;
        public List<Vehiculo> getColVehiculos() => colVehiculos;
        public void addAlquiler(Alquiler alquiler)
        {
            colAlquileres.Add(alquiler);
        }
        public void addVehiculo(Vehiculo vehiculo)
        {
            colVehiculos.Add(vehiculo);
        }
    }
}
