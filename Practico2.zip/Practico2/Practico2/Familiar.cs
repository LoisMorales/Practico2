﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practico2
{
    internal class Familiar:Vehiculo
    {
        protected short capMaletero;
        public Familiar(short numero, string matricula, string marca, string color, short capTanque, int precioAlquilerDiario, short kmLitro, short capMaletero) : base(numero, matricula, marca, color, capTanque, precioAlquilerDiario, kmLitro)
        {
            this.capMaletero = capMaletero;
        }
        public override void setDatoAdicional(short capMaletero)
        {
            this.capMaletero = capMaletero;
        }
        public override short getDatoAdicional() => capMaletero;
    }
}
