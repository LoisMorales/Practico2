﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practico2
{
    internal class Vehiculo
    {
        protected short numero;
        protected string matricula;
        protected string marca;
        protected string color;
        protected short capTanque;
        protected bool estado;
        protected int precioAlquilerDiario;
        protected short kmLitro;
        protected short datoAdicional;
        public Vehiculo() { }
        public Vehiculo(short numero, string matricula, string marca, string color, short capTanque, int precioAlquilerDiario, short kmLitro)
        {
            this.numero = numero;
            this.matricula = matricula;
            this.marca = marca;
            this.color = color;
            this.capTanque = capTanque;
            estado = false;
            this.precioAlquilerDiario = precioAlquilerDiario;
            this.kmLitro = kmLitro;
        }
        public short getNumero() => this.numero;
        public string getMatricula() => this.matricula;
        public string getMarca() => this.marca;
        public string getColor() => this.color;
        public short getCapTanque() => this.capTanque;
        public bool getEstado() => this.estado;
        public int getPrecioAlquilerDiario() => this.precioAlquilerDiario;
        public short getKmLitro() => this.kmLitro;
        public void setNumero(short numero) => this.numero = numero;
        public void setMatricula(string matricula) => this.matricula = matricula;
        public void setMarca(string marca) => this.marca = marca;
        public void setColor(string color) => this.color = color;
        public void setCapTanque(short capTanque) => this.capTanque = capTanque;
        public void setEstado(bool estado) => this.estado = estado;
        public void setPrecioAlquilerDiario(int precioAlquilerDiario) => this.precioAlquilerDiario = precioAlquilerDiario;
        public void setKmLitro(short kmLitro) => this.kmLitro = kmLitro;
        public virtual void setDatoAdicional(short datoAdicional) { this.datoAdicional = datoAdicional; }
        public virtual short getDatoAdicional() { return 0; }
    }
}
