﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practico2
{
    internal class Detalle
    {
        protected DateTime fechaRetiro;
        protected short cantDias;
        protected int cantVehiculos;
        public Detalle(int cantVehiculos, short cantDias)
        {
            fechaRetiro = DateTime.Now;
            this.cantDias = cantDias;
            this.cantVehiculos = cantVehiculos;
        }
        public int getCantVehiculos() => this.cantVehiculos;
        public DateTime getFechaRetiro() => this.fechaRetiro;
        public short getCantDias() => this.cantDias;
    }
}
