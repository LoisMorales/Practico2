﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Threading.Tasks;

namespace Practico2
{
    internal class Deportivo:Vehiculo
    {
        protected short velMaxima;
        public Deportivo(short numero, string matricula, string marca, string color, short capTanque, int precioAlquilerDiario, short kmLitro, short velMaxima) : base(numero,matricula,marca,color,capTanque,precioAlquilerDiario,kmLitro) 
        {
            this.velMaxima = velMaxima;
        }
        public override void setDatoAdicional(short velMaxima) => this.velMaxima = velMaxima;
        public override short getDatoAdicional() => velMaxima;
    }
}
